# Offline v5 report

Status: incomplete
Speed: not_measured; memory: unavailable
Preparation: unavailable; size: unavailable; profiles: not_requested
Quality: not_evaluated

Cell | Status | Baseline p95 ms | Candidate p95 ms
--- | --- | --- | ---
B1/2 | incomplete | - | -
B2/2 | incomplete | - | -
B3/2 | incomplete | - | -
B4/2 | incomplete | - | -

All cells faster above noise: False
All cells meet threshold: False
No independent confirmation or automatic quality-preservation approval.
stage_not_passed

Comparison design: not_applicable
Model loads: 4
Monitoring overhead validation is informational, not an acceptance gate.
Observed series variability does not rule out a cross-session systematic shift.
