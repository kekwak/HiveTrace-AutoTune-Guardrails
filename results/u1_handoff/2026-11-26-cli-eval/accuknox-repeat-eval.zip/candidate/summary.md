# Offline v5 report

Status: rejected
Speed: below_target; memory: measured
Preparation: measured; size: measured; profiles: not_requested
Quality: not_evaluated

Cell | Status | Baseline p95 ms | Candidate p95 ms
--- | --- | --- | ---
B1/1 | inconclusive | 127.54473124999998 | 113.83179
B1/64 | inconclusive | 1941.05719505 | 1935.07167905
B2/1 | inconclusive | 135.12244404999998 | 85.41755805
B2/32 | rejected | 1964.2732557 | 1983.9955126
B3/1 | inconclusive | 119.84877404999999 | 118.5223366
B3/16 | inconclusive | 2025.49742865 | 2042.5691880499999
B4/1 | rejected | 215.98680145 | 221.11904665
B4/8 | rejected | 2083.0006129 | 2094.26290595

All cells faster above noise: False
All cells meet threshold: False
No independent confirmation or automatic quality-preservation approval.

Comparison design: unpaired_reference
Model loads: 8
Monitoring overhead validation is informational, not an acceptance gate.
Observed series variability does not rule out a cross-session systematic shift.
