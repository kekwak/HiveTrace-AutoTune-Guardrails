"""One bounded sequential diagnostic on the newly allocated GPU."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import zipfile

BASE = Path('/workspace/u1-new-families-20261125')
OUT = BASE / 'root-cause-20261125-2100'
OUT.mkdir(exist_ok=False)
envs = {'protectai': Path('/workspace/u1-encoder-smoke-2026-11-09/u1-env'), 'accuknox': BASE / 'd3-env'}
os.environ.update(HF_HOME=str(BASE / 'hf-cache'), HF_HUB_DISABLE_IMPLICIT_TOKEN='1')
for key in ('HF_HUB_OFFLINE', 'TRANSFORMERS_OFFLINE'):
    os.environ.pop(key, None)
jobs = []
for model in ('protectai', 'accuknox'):
    for route in ('native', 'adapter'):
        name = 'replay-' + model + '-' + route
        jobs.append((name, envs[model], [BASE / 'diagnose_gpu_v2.py', '--repo', BASE / 'repo',
            '--config', BASE / 'repo/configs/v4' / (model + '.json'), '--environment', envs[model],
            '--output', OUT / name, '--route', route, '--loading', 'default']))
for repeat in range(3):
    cases = ('protectai-direct', 'protectai-warm') if repeat % 2 == 0 else ('protectai-warm', 'protectai-direct')
    for case in cases:
        name = case + '-' + str(repeat)
        jobs.append((name, envs['protectai'], [BASE / 'root_cause_probe.py', '--case', case, '--output', OUT / name]))
for case in ('primitives', 'protectai-adapter', 'accuknox-adapter'):
    name = case + '-async'
    jobs.append((name, envs['accuknox' if case.startswith('accuknox') else 'protectai'],
        [BASE / 'root_cause_probe.py', '--case', case, '--blocking', '0', '--output', OUT / name]))
state = {'diagnostic_only': True, 'approval': False, 'jobs': []}
deadline = time.monotonic() + 1800

def save():
    tmp = OUT / 'status.tmp'
    tmp.write_text(json.dumps(state, indent=2))
    tmp.replace(OUT / 'status.json')

try:
    for name, env, arguments in jobs:
        row = {'name': name, 'status': 'running', 'started_at': time.time()}
        state['jobs'].append(row)
        save()
        if time.monotonic() >= deadline:
            row['status'] = 'not_run'
            save()
            continue
        print('START', name, flush=True)
        with (OUT / (name + '.log')).open('w') as stream:
            p = subprocess.Popen([str(env / 'venv/bin/python'), *map(str, arguments)],
                stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                row['exit_code'] = p.wait(timeout=min(240, deadline - time.monotonic()))
            except BaseException as error:
                os.killpg(p.pid, signal.SIGTERM)
                try:
                    p.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(p.pid, signal.SIGKILL)
                    p.wait()
                row.update(status='interrupted', error_type=type(error).__name__)
        report = OUT / name / 'result.json'
        if report.exists():
            r = json.loads(report.read_text())
            if row['status'] == 'running':
                row['status'] = r['status']
            row['phase'] = r.get('phase')
            row['error_type'] = r.get('error_type')
        elif row['status'] == 'running':
            row['status'] = 'incomplete'
        row['finished_at'] = time.time()
        save()
        print(json.dumps(row), flush=True)
finally:
    save()
    for p in (Path(__file__), BASE / 'root_cause_probe.py', BASE / 'diagnose_gpu_v2.py'):
        (OUT / p.name).write_bytes(p.read_bytes())
    archive = Path(str(OUT) + '.zip')
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:
                z.write(p, str(p.relative_to(OUT)))
    print('ARCHIVE', archive, hashlib.sha256(archive.read_bytes()).hexdigest(), flush=True)
