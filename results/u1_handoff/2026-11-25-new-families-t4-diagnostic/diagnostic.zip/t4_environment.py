import ctypes
import importlib.metadata
import platform
import random
import site
import sys
from pathlib import Path

def configure_gpu(environment):
    import numpy as np
    import torch
    from u1_benchmark.core import read
    from u1_benchmark.v4_evidence import runtime
    from followup.team_lock import verify_inventory
    if Path(sys.prefix).resolve() != (Path(environment) / 'venv').resolve():
        raise RuntimeError('Expected diagnostic isolated venv')
    packages = {p.metadata['Name']: p.version for p in importlib.metadata.distributions() if p.metadata.get('Name')}
    verify_inventory(read(Path(environment) / 'setup/lock.json'), packages)
    if platform.system() != 'Linux' or sys.version_info[:2] != (3, 13):
        raise RuntimeError('Expected Linux/Python 3.13')
    if not torch.cuda.is_available() or torch.cuda.get_device_name(0) not in ('Tesla T4', 'NVIDIA T4'):
        raise RuntimeError('Expected T4; no CPU fallback')
    if torch.version.cuda != '13.0' or torch.backends.cudnn.version() != 91900:
        raise RuntimeError('Pinned CUDA/cuDNN mismatch')
    libs = [p for base in site.getsitepackages() for p in Path(base).glob('nvidia/cu13/lib/libnvrtc-builtins.so.13.0')]
    if not libs:
        raise RuntimeError('NVRTC builtins missing')
    ctypes.CDLL(str(libs[0]), mode=ctypes.RTLD_GLOBAL)
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)
    torch.cuda.manual_seed_all(42)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    torch.use_deterministic_algorithms(True, warn_only=True)
    result = runtime()
    result.update(diagnostic_only=True, profile='t4-loading-diagnostic',
                  native_bf16_supported=torch.cuda.is_bf16_supported(including_emulation=False))
    return result
