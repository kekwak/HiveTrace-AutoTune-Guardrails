"""Diagnostic only: capture the d3 load/request failure without changing config."""
import json
from pathlib import Path
import sys
import traceback

from u1_benchmark.v4_adapters import load_adapter
from u1_benchmark.v4_evidence import configure_gpu
from u1_benchmark.v4_preparation import validate_settings

root = Path('/workspace/u1-new-families-20261125')
result = {'diagnostic_only': True, 'cuda_launch_blocking': True, 'phase': 'environment'}
adapter = None
try:
    configure_gpu(str(root / 'd3-env'))
    spec = json.loads((root / 'accuknox-smoke.json').read_text())['baseline']
    result['phase'] = 'load'
    adapter = load_adapter(validate_settings(spec), root / 'accuknox-diagnostic-model')
    result['phase'] = 'request'
    result['responses'] = adapter.request_batch(['Library hours?'])
except BaseException as error:
    result.update(status='failed', error_type=type(error).__name__, traceback=traceback.format_exc())
else:
    result['status'] = 'passed'
finally:
    with (root / (sys.argv[1] if len(sys.argv) > 1 else 'accuknox-load-diagnostic.json')).open('x') as handle:
        json.dump(result, handle, indent=2)
    print(json.dumps(result))
    if adapter is not None:
        adapter.close()
