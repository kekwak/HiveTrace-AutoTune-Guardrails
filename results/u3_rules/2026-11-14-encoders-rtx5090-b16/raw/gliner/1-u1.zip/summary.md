# Offline v4 report

Status: exploratory
Speed: exploratory; memory: measured
Preparation: measured; size: measured; profiles: not_requested
Quality: not_evaluated

Cell | Status | Baseline p95 ms | Candidate p95 ms
--- | --- | --- | ---
B1/16 | exploratory | 93.06827855 | 95.04793670000001

All cells faster above noise: False
All cells meet threshold: False
No independent confirmation or automatic quality-preservation approval.
