"""Sequential, isolated loading diagnostics. No benchmark or production fallback."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import traceback
import zipfile

BASE = Path('/workspace/u1-new-families-20261125')
OUT = BASE / 'cuda-debug-20261125-1938'
OUT.mkdir(exist_ok=False)
os.environ.update(HF_HOME=str(BASE / 'hf-cache'), HF_HUB_DISABLE_IMPLICIT_TOKEN='1')
for key in ('HF_HUB_OFFLINE', 'TRANSFORMERS_OFFLINE'):
    os.environ.pop(key, None)
state = {'diagnostic_only': True, 'approval': False, 'cases': []}
deadline = time.monotonic() + 1200
cases = [('protectai', route, 'default') for route in
         ('native', 'local', 'legacy-dtype', 'loading-info', 'prepared-inputs', 'adapter')]
cases += [('protectai', 'adapter', 'serial')]
cases += [('accuknox', route, loading) for loading in ('default', 'serial') for route in ('native', 'adapter')]

def save():
    temporary = OUT / 'status.tmp'
    temporary.write_text(json.dumps(state, indent=2) + '\n')
    temporary.replace(OUT / 'status.json')

try:
    for model, route, loading in cases:
        name = '-'.join((model, route, loading))
        if time.monotonic() >= deadline:
            state['cases'].append({'name': name, 'status': 'not_run', 'reason': 'deadline'})
            save()
            continue
        environment = (BASE / 'd3-env' if model == 'accuknox' else
                       Path('/workspace/u1-encoder-smoke-2026-11-09/u1-env'))
        args = [str(environment / 'venv/bin/python'), str(BASE / 'diagnose_gpu_v2.py'),
            '--repo', str(BASE / 'repo'), '--config', str(BASE / 'repo/configs/v4' / (model + '.json')),
            '--environment', str(environment), '--output', str(OUT / name), '--route', route,
            '--loading', loading]
        row = {'name': name, 'status': 'running', 'started_at': time.time()}
        state['cases'].append(row)
        save()
        print('START', name, flush=True)
        with (OUT / (name + '.log')).open('w') as log:
            p = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                row['exit_code'] = p.wait(timeout=min(180, deadline - time.monotonic()))
            except BaseException as error:
                os.killpg(p.pid, signal.SIGTERM)
                try:
                    p.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(p.pid, signal.SIGKILL)
                    p.wait()
                row.update(status='interrupted', error_type=type(error).__name__)
        result = OUT / name / 'result.json'
        if result.exists():
            report = json.loads(result.read_text())
            if row['status'] == 'running':
                row['status'] = report['status']
            row.update(phase=report.get('phase'), error_type=report.get('error_type'))
        elif row['status'] == 'running':
            row['status'] = 'incomplete'
        row['finished_at'] = time.time()
        save()
        print(json.dumps(row), flush=True)
except BaseException:
    (OUT / 'launcher-error.txt').write_text(traceback.format_exc())
    raise
finally:
    save()
    for src in (Path(__file__), BASE / 'diagnose_gpu_v2.py'):
        (OUT / src.name).write_bytes(src.read_bytes())
    archive = Path(str(OUT) + '.zip')
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
        for path in sorted(OUT.rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                z.write(path, str(path.relative_to(OUT)))
    print('ARCHIVE', archive, hashlib.sha256(archive.read_bytes()).hexdigest(), flush=True)
