"""Controlled native CUDA operations and first-request diagnostics; no approval."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--case', choices=('primitives', 'protectai-direct', 'protectai-warm',
                                      'protectai-adapter', 'accuknox-adapter'), required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--blocking', choices=('0', '1'), default='1')
args = parser.parse_args()
os.environ.update(CUDA_VISIBLE_DEVICES='0', CUDA_LAUNCH_BLOCKING=args.blocking,
                  HF_DEACTIVATE_ASYNC_LOAD='0', OMP_NUM_THREADS='2',
                  CUBLAS_WORKSPACE_CONFIG=':4096:8', USE_HUB_KERNELS='NO',
                  HF_HUB_DISABLE_IMPLICIT_TOKEN='1', HF_HOME='/workspace/u1-new-families-20261125/hf-cache')
BASE = Path('/workspace/u1-new-families-20261125')
sys.path.insert(0, str(BASE / 'repo'))
args.output.mkdir(exist_ok=False, parents=True)
result = {'diagnostic_only': True, 'approval': False, 'status': 'running',
          'case': args.case, 'cuda_launch_blocking': args.blocking == '1',
          'async_loading': 'default', 'steps': [],
          'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}

def save(phase):
    result['phase'] = phase
    tmp = args.output / 'result.tmp'
    tmp.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    tmp.replace(args.output / 'result.json')

try:
    save('environment')
    import torch
    from u1_benchmark.v4_evidence import configure_gpu
    environment = BASE / 'd3-env' if args.case == 'accuknox-adapter' else Path('/workspace/u1-encoder-smoke-2026-11-09/u1-env')
    result['runtime'] = configure_gpu(environment)
    if args.case == 'primitives':
        for shape in ((512, 768), (4096, 2560)):
            for dtype in (torch.float32, torch.bfloat16):
                x = torch.randn(shape, dtype=torch.float32).to(dtype)
                row = {'operation': 'host-device-roundtrip', 'shape': list(shape), 'dtype': str(dtype), 'status': 'running'}
                result['steps'].append(row)
                save('copy')
                for repeat in range(5):
                    y = x.to('cuda:0')
                    torch.cuda.synchronize()
                    if not torch.equal(y.cpu(), x):
                        raise RuntimeError('CUDA roundtrip differs')
                    del y
                row.update(status='passed', repeats=5)
        x = torch.randn(1, 512, 768)
        weight = torch.randn(768, 768)
        bias = torch.randn(768)
        reference = torch.nn.functional.linear(x.double(), weight.double(), bias.double())
        gx, gw, gb = x.cuda(), weight.cuda(), bias.cuda()
        torch.cuda.synchronize()
        row = {'operation': 'linear', 'input_shape': list(gx.shape), 'input_stride': list(gx.stride()),
               'weight_shape': list(gw.shape), 'status': 'running'}
        result['steps'].append(row)
        save('linear')
        for repeat in range(5):
            actual = torch.nn.functional.linear(gx, gw, gb)
            torch.cuda.synchronize()
            error = (actual.cpu().double() - reference).abs().max().item()
            if not bool(torch.isfinite(actual).all()) or error > 0.002:
                raise RuntimeError('Linear numerical mismatch')
        row.update(status='passed', repeats=5, max_absolute_error=error)
        for length in (5, 8):
            q = torch.randn(24, length, 64)
            k = torch.randn(24, 512, 64).transpose(-1, -2)
            reference = torch.bmm(q.double(), k.double())
            gq, gk = q.cuda(), k.cuda()
            torch.cuda.synchronize()
            row = {'operation': 'bmm', 'query_shape': list(gq.shape), 'key_shape': list(gk.shape),
                   'query_stride': list(gq.stride()), 'key_stride': list(gk.stride()), 'status': 'running'}
            result['steps'].append(row)
            save('bmm')
            for repeat in range(5):
                actual = torch.bmm(gq, gk)
                torch.cuda.synchronize()
                error = (actual.cpu().double() - reference).abs().max().item()
                if not bool(torch.isfinite(actual).all()) or error > 0.002:
                    raise RuntimeError('BMM numerical mismatch')
            row.update(status='passed', repeats=5, max_absolute_error=error)
    elif args.case in ('protectai-direct', 'protectai-warm'):
        from transformers import AutoModelForSequenceClassification, AutoTokenizer
        spec = json.loads((BASE / 'repo/configs/v4/protectai.json').read_text())['baseline']
        save('load')
        tok = AutoTokenizer.from_pretrained(spec['tokenizer']['repo'], revision=spec['tokenizer']['revision'], local_files_only=True)
        model = AutoModelForSequenceClassification.from_pretrained(spec['weights']['repo'],
            revision=spec['weights']['revision'], dtype=torch.float32, local_files_only=True).to('cuda:0').eval()
        torch.cuda.synchronize()
        texts = ['Library hours?', 'The public library is open.']
        batches = [texts[:1], texts] if args.case == 'protectai-warm' else [texts]
        for values in batches:
            inputs = tok(values, padding=True, truncation=False, return_tensors='pt').to('cuda:0')
            torch.cuda.synchronize()
            row = {'batch_size': len(values), 'shape': list(inputs['input_ids'].shape), 'status': 'running'}
            result['steps'].append(row)
            save('request')
            with torch.inference_mode():
                logits = model(**inputs).logits
                torch.cuda.synchronize()
                if not bool(torch.isfinite(logits).all()):
                    raise RuntimeError('Nonfinite logits')
                row.update(status='passed', logits=logits.cpu().tolist())
    else:
        from u1_benchmark.v4_adapters import load_adapter
        from u1_benchmark.v4_preparation import validate_settings
        model_name = args.case.split('-')[0]
        spec = validate_settings(json.loads((BASE / 'repo/configs/v4' / (model_name + '.json')).read_text())['baseline'])
        save('load')
        adapter = load_adapter(spec, args.output / 'adapter')
        torch.cuda.synchronize()
        result['metadata'] = adapter.metadata
        texts = ['Library hours?', 'The public library is open.']
        for values in (texts, texts[:1], texts):
            save('request')
            answers = adapter.request_batch(values)
            torch.cuda.synchronize()
            result['steps'].append({'batch_size': len(values), 'status': 'passed', 'responses': answers})
        if result['steps'][0]['responses'] != result['steps'][-1]['responses']:
            raise RuntimeError('A-B-A responses differ')
        adapter.close()
    result['status'] = 'passed'
except BaseException as error:
    result.update(status='failed', error_type=type(error).__name__, traceback=traceback.format_exc())
finally:
    result['finished_at'] = time.time()
    save(result.get('phase', 'startup'))
print(json.dumps({key: result[key] for key in ('case', 'status', 'phase')}))
raise SystemExit(0 if result['status'] == 'passed' else 1)
