"""One-off native GPU smoke; invokes the existing CLI, never benchmark series."""
import json
import os
from pathlib import Path
import subprocess
import time
import traceback

ROOT = Path('/workspace/u1-new-families-20261125')
REPO = ROOT / 'repo'
OLD = Path('/workspace/u1-encoder-smoke-2026-11-09')
DRIVER = OLD / 'bootstrap/driver-venv/bin/python'
RTX = OLD / 'u1-env'
D3 = ROOT / 'd3-env'
STATUS = ROOT / 'launch-status.json'
started = time.monotonic()
state = {'status': 'running', 'scope': 'native smoke only', 'quality_evaluated': False, 'stages': []}
os.environ.update(CUDA_VISIBLE_DEVICES='0', HF_HOME=str(ROOT / 'hf-cache'),
                  USE_HUB_KERNELS='NO', PYTHONUNBUFFERED='1', TOKENIZERS_PARALLELISM='false',
                  PIP_CACHE_DIR=str(ROOT / 'pip-cache'))


def save():
    temp = STATUS.with_suffix('.tmp')
    temp.write_text(json.dumps(state, indent=2) + '\n')
    temp.replace(STATUS)


def command(name, args, timeout):
    entry = {'name': name, 'status': 'running', 'started_at': time.time(), 'args': list(map(str, args))}
    state['stages'].append(entry)
    save()
    try:
        with (ROOT / (name + '.log')).open('x') as log:
            completed = subprocess.run(list(map(str, args)), cwd=REPO, stdout=log, stderr=subprocess.STDOUT,
                                       timeout=min(timeout, max(1, 3900 - (time.monotonic() - started))))
        entry.update(status='completed' if completed.returncode == 0 else 'failed', returncode=completed.returncode)
    except Exception as error:
        entry.update(status='failed', error_type=type(error).__name__)
    entry['finished_at'] = time.time()
    save()
    return entry['status'] == 'completed'


def smoke(name, environment):
    config = json.loads((REPO / 'configs/v4' / (name + '.json')).read_text())
    config['environment'] = str(environment)
    config['data']['path'] = str(REPO / 'data/speed/new-families-20261125')
    config['timeout_seconds'] = 600
    # Small sizes are explicit smoke scope, not an automatic OOM fallback.
    config['batch_sizes_by_bucket'] = {key: [2] for key in config['buckets']}
    config['mode'] = 'smoke'
    path = ROOT / (name + '-smoke.json')
    path.write_text(json.dumps(config, indent=2) + '\n')
    return command(name + '-smoke', [environment / 'venv/bin/python', 'tools/benchmark.py', 'preflight',
        '--config', path, '--environment', environment, '--output', ROOT / (name + '-results')], 650)


try:
    save()
    smoke('protectai', RTX)
    installed = command('d3-setup', [DRIVER, 'tools/benchmark.py', 'setup', '--profile', 'team-d3',
                                    '--environment', D3], 2400)
    if installed:
        smoke('accuknox', D3)
    state['status'] = 'completed' if all(s['status'] == 'completed' for s in state['stages']) else 'partial'
except BaseException as error:
    state.update(status='failed', error_type=type(error).__name__)
    (ROOT / 'launch-error.txt').write_text(traceback.format_exc())
finally:
    state['seconds'] = time.monotonic() - started
    save()
