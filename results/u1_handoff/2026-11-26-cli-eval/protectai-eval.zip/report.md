# CLI evaluation

Status: reference_pass
Comparison: unpaired reference; no independent replication.
Quality evaluated: False

Cell | Status | Baseline p95 ms | Candidate p95 ms
--- | --- | --- | ---
B1/1 | reference_pass | 56.88458155 | 8.756069499999999
B1/256 | reference_pass | 1488.1672322 | 949.2892571000001
