# Offline v5 report

Status: preflight_passed
Speed: not_measured; memory: measured
Preparation: partial; size: measured; profiles: not_requested
Quality: not_evaluated

Cell | Status | Baseline p95 ms | Candidate p95 ms
--- | --- | --- | ---
B1/2 | preflight_passed | - | -

All cells faster above noise: False
All cells meet threshold: False
No independent confirmation or automatic quality-preservation approval.

Comparison design: not_applicable
Model loads: 1
Monitoring overhead validation is informational, not an acceptance gate.
Observed series variability does not rule out a cross-session systematic shift.
