"""Diagnostic only: direct HF and adapter in isolated ordinary-async processes."""
import argparse
import json
import os
from pathlib import Path
import traceback

import torch
from u1_benchmark.v4_evidence import configure_gpu

parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('native', 'adapter'))
parser.add_argument('--tag', default='')
args = parser.parse_args()
assert os.environ.get('CUDA_LAUNCH_BLOCKING', '0') == '0'
root = Path('/workspace/u1-new-families-20261125')
result = {'diagnostic_only': True, 'mode': args.mode, 'cuda_launch_blocking': False,
          'environment': {key: os.environ.get(key) for key in ('CUBLAS_WORKSPACE_CONFIG', 'OMP_NUM_THREADS')}}
try:
    configure_gpu('/workspace/u1-encoder-smoke-2026-11-09/u1-env')
    spec = json.loads((root / 'protectai-smoke.json').read_text())['baseline']
    if args.mode == 'native':
        from transformers import AutoModelForSequenceClassification, AutoTokenizer
        tok = AutoTokenizer.from_pretrained(**{
            'pretrained_model_name_or_path': spec['tokenizer']['repo'],
            'revision': spec['tokenizer']['revision'], 'local_files_only': True})
        model = AutoModelForSequenceClassification.from_pretrained(
            spec['weights']['repo'], revision=spec['weights']['revision'],
            dtype=torch.float32, local_files_only=True).to('cuda:0').eval()
        inputs = tok(['Library hours?'], padding=True, truncation=False, return_tensors='pt').to('cuda:0')
        with torch.inference_mode():
            logits = model(**inputs).logits
            torch.cuda.synchronize()
            result.update(logits=logits.cpu().tolist(), finite=bool(logits.isfinite().all()))
    else:
        from u1_benchmark.v4_adapters import load_adapter
        from u1_benchmark.v4_preparation import validate_settings
        adapter = load_adapter(validate_settings(spec), root / 'protectai-async-diagnostic-model')
        result['responses'] = adapter.request_batch(['Library hours?'])
except BaseException as error:
    result.update(status='failed', error_type=type(error).__name__, traceback=traceback.format_exc())
else:
    result['status'] = 'passed'
finally:
    with (root / ('protectai-async-' + args.mode + args.tag + '.json')).open('x') as handle:
        json.dump(result, handle, indent=2)
    print(json.dumps(result))
