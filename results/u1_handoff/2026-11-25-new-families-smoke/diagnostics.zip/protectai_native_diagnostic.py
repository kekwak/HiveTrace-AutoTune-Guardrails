"""Diagnostic only: direct Transformers invocation, no measurement or approval."""
import json
from pathlib import Path
import traceback

import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer

from u1_benchmark.v4_evidence import configure_gpu

root = Path('/workspace/u1-new-families-20261125')
result = {'diagnostic_only': True, 'cuda_launch_blocking': True, 'steps': []}
try:
    configure_gpu('/workspace/u1-encoder-smoke-2026-11-09/u1-env')
    spec = json.loads((root / 'protectai-smoke.json').read_text())['baseline']
    tokenizer = AutoTokenizer.from_pretrained(
        spec['tokenizer']['repo'], revision=spec['tokenizer']['revision'], local_files_only=True)
    model = AutoModelForSequenceClassification.from_pretrained(
        spec['weights']['repo'], revision=spec['weights']['revision'],
        dtype=torch.float32, local_files_only=True).to('cuda:0').eval()
    result['attention'] = model.config._attn_implementation
    for values in (['Library hours?'], ['Library hours?', 'The public library is open.']):
        step = {'batch_size': len(values), 'status': 'running'}
        result['steps'].append(step)
        inputs = tokenizer(values, padding=True, truncation=False, return_tensors='pt').to('cuda:0')
        step['shape'] = list(inputs['input_ids'].shape)
        with torch.inference_mode():
            logits = model(**inputs).logits
            torch.cuda.synchronize()
            step.update(status='passed', finite=bool(logits.isfinite().all()), logits=logits.cpu().tolist())
except BaseException as error:
    result.update(status='failed', error_type=type(error).__name__, traceback=traceback.format_exc())
else:
    result['status'] = 'passed'
finally:
    output = root / 'protectai-native-diagnostic.json'
    with output.open('x') as handle:
        json.dump(result, handle, indent=2)
    print(json.dumps(result))
