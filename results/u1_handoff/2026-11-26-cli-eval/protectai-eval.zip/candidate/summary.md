# Offline v5 report

Status: reference_pass
Speed: pass; memory: measured
Preparation: measured; size: measured; profiles: not_requested
Quality: not_evaluated

Cell | Status | Baseline p95 ms | Candidate p95 ms
--- | --- | --- | ---
B1/1 | reference_pass | 56.88458155 | 8.756069499999999
B1/256 | reference_pass | 1488.1672322 | 949.2892571000001

All cells faster above noise: True
All cells meet threshold: True
No independent confirmation or automatic quality-preservation approval.

Comparison design: unpaired_reference
Model loads: 2
Monitoring overhead validation is informational, not an acceptance gate.
Observed series variability does not rule out a cross-session systematic shift.
